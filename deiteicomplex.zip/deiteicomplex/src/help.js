const help = (prefix) => {
	return `
<══════════════════════>
      *TOBI BOT*
 <══════════════════════>

__█████████  ● ᏴϴͲ●ᎷᎬΝႮ●         
__█▄█████▄█   *DONO*    : TOBI
__█▼▼▼▼▼█ 
_██ᏴϴͲ Ꮩ1.0██▌ 
__█▲▲▲▲▲█ 
__█████████ 
____██_____██

┌─────────❶.❷────────

🧐 *informações*
  🐊 Prefix: 「  ${prefix}  」
  🐊 Criador : TOBI (base Vrau) 
🧐 *SOBRE*
  │
  ├─ 🐊 ${prefix}info
  ├─ 🐊 ${prefix}blocklist
  ├─ 🐊 ${prefix}chatlist
  ├─ 🐊 ${prefix}ping
  ├─ 🐊 ${prefix}dono
  ├─ 🐊 ${prefix}appbot
  └─ 🐊 ${prefix}bugreport
🧐 *FAZER*
  │
  ├─ 🐊 ${prefix}sticker
  ├─ 🐊 ${prefix}stickergif
  ├─ 🐊 ${prefix}toimg
  ├─ 🐊 ${prefix}tomp3
  ├─ 🐊 ${prefix}bpink
  ├─ 🐊 ${prefix}marvellogo
  ├─ 🐊 ${prefix}snowwrite
  ├─ 🐊 ${prefix}3dtext
  ├─ 🐊 ${prefix}ninjalogo
  ├─ 🐊 ${prefix}water
  ├─ 🐊 ${prefix}firetext
  ├─ 🐊 ${prefix}logowolf
  ├─ 🐊 ${prefix}logowolf2
  ├─ 🐊 ${prefix}phlogo
  ├─ 🐊 ${prefix}glitch
  ├─ 🐊 ${prefix}neonlogo
  ├─ 🐊 ${prefix}neonlogo2
  ├─ 🐊 ${prefix}lionlogo
  ├─ 🐊 ${prefix}jokerlogo
  ├─ 🐊 ${prefix}shadow
  ├─ 🐊 ${prefix}burnpaper
  ├─ 🐊 ${prefix}coffee
  ├─ 🐊 ${prefix}lovepaper
  ├─ 🐊 ${prefix}woodblock
  ├─ 🐊 ${prefix}qowheart
  ├─ 🐊 ${prefix}mutgrass
  ├─ 🐊 ${prefix}undergocean
  ├─ 🐊 ${prefix}woodenboards
  ├─ 🐊 ${prefix}wolfmetal
  ├─ 🐊 ${prefix}metalictglow
  ├─ 🐊 ${prefix}8bit
  ├─ 🐊 ${prefix}ttp
  ├─ 🐊 ${prefix}herrypotter
  ├─ 🐊 ${prefix}pubglogo
  └─ 🐊 ${prefix}quotemaker
◪🧐 *MEDIA*
  │
  ├─ 🐊 ${prefix}trendtwit
  ├─ 🐊 ${prefix}randomkpop
  └─ 🐊 ${prefix}ytsearch
🧐 *escolaKKKKK*
  │
  ├─ 🐊 ${prefix}wiki
  ├─ 🐊 ${prefix}wikien
  ├─ 🐊 ${prefix}nulis
  ├─ 🐊 ${prefix}quotes
  ├─ 🐊 ${prefix}quotes2
  └─ 🐊 ${prefix}artinama
🧐 *KERANG AJAIB*
  │
  ├─ 🐊 ${prefix}apakah
  ├─ 🐊 ${prefix}kapankah
  ├─ 🐊 ${prefix}rate
  └─ 🐊 ${prefix}bisakah
🧐 *DOWNLOADER*
  │
  ├─ 🐊 ${prefix}images
  ├─ 🐊 ${prefix}ytmp3
  ├─ 🐊 ${prefix}ytmp4
  ├─ 🐊 ${prefix}tiktok
  └─ 🐊 ${prefix}joox
🧐 *MEME*
  │
  ├─ 🐊 ${prefix}meme
  └─ 🐊 ${prefix}memeindo
🧐 *SOM*
  │
  ├─ 🐊 ${prefix}play
  └─ 🐊 ${prefix}tts
🧐 *MÚSICA*
  │
  ├─ 🐊 ${prefix}lirik
  └─ 🐊 ${prefix}chord
🧐 *ISLAM*
  │
  └─ 🐊 ${prefix}quran
🧐 *STALK*
  │
  ├─ 🐊 ${prefix}tiktokstalk
  └─ 🐊 ${prefix}igstalk
🧐 *WIBU*
  │
  ├─ 🐊 ${prefix}neonime
  ├─ 🐊 ${prefix}pokemon
  ├─ 🐊 ${prefix}loli
  ├─ 🐊 ${prefix}waifu
  ├─ 🐊 ${prefix}randomanime
  ├─ 🐊 ${prefix}husbu
  ├─ 🐊 ${prefix}husbu2
  ├─ 🐊 ${prefix}wait
  └─ 🐊 ${prefix}nekonime
🧐 *DIVERSÃO*
  │
  ├─ 🐊 ${prefix}alay
  ├─ 🐊 ${prefix}gantengcek
  ├─ 🐊 ${prefix}watak
  ├─ 🐊 ${prefix}hobby
  ├─ 🐊 ${prefix}game
  ├─ 🐊 ${prefix}bucin
  ├─ 🐊 ${prefix}trust
  ├─ 🐊 ${prefix}dare
  └─ 🐊 ${prefix}simi
🧐 *INFORMAÇÃO*
  │
  ├─ 🐊 ${prefix}bahasa
  ├─ 🐊 ${prefix}kodenegara
  ├─ 🐊 ${prefix}kbbi
  ├─ 🐊 ${prefix}fakta
  ├─ 🐊 ${prefix}infocuaca
  ├─ 🐊 ${prefix}infogempa
  ├─ 🐊 ${prefix}jadwaltvnow
  └─ 🐊 ${prefix}covid
🧐 *COMANDOS DO TOBI*
  │
  ├─ 🐊 ${prefix}setprefix
  ├─ 🐊 ${prefix}block
  ├─ 🐊 ${prefix}bc
  ├─ 🐊 ${prefix}bcgc
  ├─ 🐊 ${prefix}clone
  └─ 🐊 ${prefix}clearall
🧐 *Não faço ideia da categoria desses*
  │
  ├─ 🐊 ${prefix}send
  ├─ 🐊 ${prefix}wame
  ├─ 🐊 ${prefix}virtex
  ├─ 🐊 ${prefix}exe
  ├─ 🐊 ${prefix}qrcode
  ├─ 🐊 ${prefix}afk
  ├─ 🐊 ${prefix}timer
  ├─ 🐊 ${prefix}fml
  └─ 🐊 ${prefix}fml2
`
}

exports.help = help
