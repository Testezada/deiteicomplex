const config = {
        botName: 'Vrau',
        ownerName: 'Tobi',
        youtube: 'Em',
        instagram: 'Em',
}
